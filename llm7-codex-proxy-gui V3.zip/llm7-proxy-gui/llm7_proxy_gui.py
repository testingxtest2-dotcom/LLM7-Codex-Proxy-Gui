#!/usr/bin/env python3
"""
LLM7 Codex Proxy - Control Panel
================================

A point-and-click front end for theRizwan/llm7-codex-proxy.
No terminal commands required.

What it does for you:
  1. Stores your LLM7 API key permanently in the Windows user environment
     (HKCU\\Environment -> LLM7_API_KEY) and notifies running apps.
  2. Writes / patches %USERPROFILE%\\.codex\\config.toml with the llm7proxy
     provider block (keeping any other settings you already had).
  3. Installs requirements.txt, starts and stops the proxy, streams its log,
     and checks /health - all from buttons.

Runs on Windows 10/11 with the Python that ships tkinter (the default
python.org installer). Works on macOS/Linux too, except the permanent
environment-variable step, which is Windows-only.
"""

from __future__ import annotations

import json
import os
import queue
import shutil
import socket
import subprocess
import sys
import threading
import urllib.error
import urllib.request
import webbrowser
from datetime import datetime
from pathlib import Path

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox
    from tkinter.scrolledtext import ScrolledText

    HAVE_TK = True
except Exception:  # pragma: no cover - headless environments
    HAVE_TK = False

IS_WINDOWS = os.name == "nt"
if IS_WINDOWS:  # pragma: no cover - platform specific
    import ctypes
    import winreg

# ---------------------------------------------------------------- constants

APP_NAME = "LLM7 Codex Proxy"
ENV_KEY = "LLM7_API_KEY"
PROVIDER_KEY = "llm7proxy"
SCRIPT_NAME = "llm7_codex_proxy.py"
DEFAULT_PORT = "5011"
DEFAULT_CODEX_MODEL = "gpt-5.5"
DEFAULT_UPSTREAM_MODEL = "default"
DASH_URL = "https://dash.llm7.io/"
STARTUP_FILE = "LLM7 Codex Proxy.cmd"
FREE_KEY = "unused"
MANAGED_COMMENT = "# Managed by the LLM7 Codex Proxy control panel"
ORIGINAL_SUFFIX = ".llm7-original"
NO_ORIGINAL_SUFFIX = ".llm7-no-original"

# Palette
C_CANVAS = "#FFFFFF"
C_SOFT = "#F9F8F7"
C_SURFACE2 = "#F0EFED"
C_BORDER = "#E6E5E3"
C_TEXT = "#2C2C2B"
C_TEXT2 = "#7D7A75"
C_BLUE = "#2783DE"
C_BLUE_SOFT = "#E5F2FC"
C_GREEN = "#2F7A52"
C_GREEN_SOFT = "#E8F1EC"
C_ORANGE = "#9A5A22"
C_ORANGE_SOFT = "#FBEBDE"
C_RED = "#A93A2F"
C_RED_SOFT = "#FCE9E7"

FONT = "Segoe UI" if IS_WINDOWS else "Helvetica"
MONO = "Consolas" if IS_WINDOWS else "Menlo"


# ------------------------------------------------------------ pure helpers
# (kept free of tkinter so they can be unit tested)


def codex_config_path() -> Path:
    return Path.home() / ".codex" / "config.toml"


def settings_path() -> Path:
    base = os.environ.get("APPDATA")
    root = Path(base) if base else Path.home()
    return root / "LLM7CodexProxyGUI" / "settings.json"


def original_backup_path() -> Path:
    """Where the untouched, pre-LLM7 config.toml is preserved."""
    path = codex_config_path()
    return path.with_name(path.name + ORIGINAL_SUFFIX)


def no_original_marker_path() -> Path:
    """Marker recording that there was no config.toml at all to begin with."""
    path = codex_config_path()
    return path.with_name(path.name + NO_ORIGINAL_SUFFIX)


def timestamp() -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def ensure_original_backup() -> str:
    """Preserve the original config exactly once, before anything is written.

    Returns "created" (original copied aside), "absent" (there was no config,
    marker written) or "exists" (a pristine copy was already kept earlier).
    """
    config = codex_config_path()
    original = original_backup_path()
    marker = no_original_marker_path()
    if original.is_file() or marker.is_file():
        return "exists"
    config.parent.mkdir(parents=True, exist_ok=True)
    if config.is_file():
        shutil.copy2(config, original)
        return "created"
    marker.write_text(
        "There was no .codex/config.toml before the LLM7 control panel wrote one.\n"
        "'Restore original config' deletes config.toml to return to that state.\n",
        encoding="utf-8",
    )
    return "absent"


def can_restore_original() -> bool:
    return original_backup_path().is_file() or no_original_marker_path().is_file()


def restore_original():
    """Put the original state back.

    Returns (action, safety_copy) where action is "restored", "removed" or
    "nothing", and safety_copy is the path the replaced file was copied to.
    """
    config = codex_config_path()
    original = original_backup_path()
    marker = no_original_marker_path()
    if not (original.is_file() or marker.is_file()):
        return ("nothing", None)

    safety = None
    if config.is_file():
        safety = config.with_suffix(".toml.before-restore-{0}".format(timestamp()))
        shutil.copy2(config, safety)

    if original.is_file():
        shutil.copy2(original, config)
        return ("restored", safety)
    if marker.is_file():
        if config.is_file():
            config.unlink()
        return ("removed", safety)
    return ("nothing", safety)


def provider_block(port: str) -> str:
    return (
        "[model_providers.{key}]\n"
        'name = "LLM7 Python Proxy"\n'
        'base_url = "http://127.0.0.1:{port}/v1"\n'
        'env_key = "{env}"\n'
        'wire_api = "responses"\n'
        "request_max_retries = 2\n"
        "stream_max_retries = 2\n"
        "stream_idle_timeout_ms = 300000\n"
    ).format(key=PROVIDER_KEY, port=port, env=ENV_KEY)


def _is_table_header(line: str) -> bool:
    s = line.strip()
    return len(s) > 2 and s.startswith("[") and s.endswith("]")


def _key_of(line: str):
    s = line.strip()
    if not s or s.startswith("#") or "=" not in s:
        return None
    return s.split("=", 1)[0].strip().strip('"').strip("'")


def split_toml(text: str):
    """Split TOML into (preamble_lines, [(header, body_lines), ...])."""
    preamble: list[str] = []
    sections: list[list] = []
    current = None
    for line in (text or "").splitlines():
        if _is_table_header(line):
            current = [line.strip(), []]
            sections.append(current)
        elif current is None:
            preamble.append(line)
        else:
            current[1].append(line)
    return preamble, [(h, b) for h, b in sections]


def patch_config_text(existing: str, port: str, codex_model: str) -> str:
    """Return config.toml text with our provider wired up.

    Existing unrelated settings and tables are preserved. Any previous
    top-level `model`/`model_provider` keys and any previous
    [model_providers.llm7proxy] table are replaced.
    """
    preamble, sections = split_toml(existing)
    target = "[model_providers.{0}]".format(PROVIDER_KEY)

    kept_pre = [
        line
        for line in preamble
        if _key_of(line) not in ("model", "model_provider")
        and line.strip() != MANAGED_COMMENT
    ]
    kept_sections = [
        (h, b) for h, b in sections if h.replace(" ", "").lower() != target.lower()
    ]

    out: list[str] = [
        MANAGED_COMMENT,
        'model_provider = "{0}"'.format(PROVIDER_KEY),
        'model = "{0}"'.format(codex_model),
    ]

    pre_body = "\n".join(kept_pre).strip("\n")
    if pre_body.strip():
        out.append("")
        out.append(pre_body)

    for header, body in kept_sections:
        out.append("")
        out.append(header)
        body_text = "\n".join(body).strip("\n")
        if body_text.strip():
            out.append(body_text)

    out.append("")
    out.append(provider_block(port).rstrip("\n"))
    return "\n".join(out).rstrip("\n") + "\n"


def valid_port(value: str) -> bool:
    return value.isdigit() and 1 <= int(value) <= 65535


def mask_key(value: str) -> str:
    if not value:
        return ""
    if value == FREE_KEY:
        return FREE_KEY
    if len(value) <= 8:
        return "*" * len(value)
    return "{0}...{1}".format(value[:4], value[-4:])


def load_settings() -> dict:
    try:
        return json.loads(settings_path().read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_settings(data: dict) -> None:
    try:
        path = settings_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except Exception:
        pass


def read_saved_key() -> str:
    """Read the persisted user environment variable (not the process copy)."""
    if not IS_WINDOWS:
        return os.environ.get(ENV_KEY, "")
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as key:
            value, _ = winreg.QueryValueEx(key, ENV_KEY)
            return str(value)
    except Exception:
        return ""


def broadcast_env_change() -> None:
    if not IS_WINDOWS:
        return
    try:
        HWND_BROADCAST = 0xFFFF
        WM_SETTINGCHANGE = 0x001A
        SMTO_ABORTIFHUNG = 0x0002
        result = ctypes.c_long()
        ctypes.windll.user32.SendMessageTimeoutW(
            HWND_BROADCAST,
            WM_SETTINGCHANGE,
            0,
            ctypes.c_wchar_p("Environment"),
            SMTO_ABORTIFHUNG,
            5000,
            ctypes.byref(result),
        )
    except Exception:
        pass


def write_saved_key(value: str) -> None:
    os.environ[ENV_KEY] = value
    if not IS_WINDOWS:
        return
    with winreg.OpenKey(
        winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_SET_VALUE
    ) as key:
        winreg.SetValueEx(key, ENV_KEY, 0, winreg.REG_EXPAND_SZ, value)
    broadcast_env_change()


def delete_saved_key() -> None:
    os.environ.pop(ENV_KEY, None)
    if not IS_WINDOWS:
        return
    try:
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_SET_VALUE
        ) as key:
            winreg.DeleteValue(key, ENV_KEY)
    except FileNotFoundError:
        pass
    broadcast_env_change()


def startup_dir() -> Path:
    base = os.environ.get("APPDATA")
    root = Path(base) if base else Path.home()
    return root / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"


def port_busy(port: str) -> bool:
    if not valid_port(port):
        return False
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.6)
        return sock.connect_ex(("127.0.0.1", int(port))) == 0


def resolve_python() -> str:
    """Console interpreter, used to run the proxy with piped output."""
    exe = sys.executable or "python"
    name = os.path.basename(exe).lower()
    if name.startswith("pythonw"):
        sibling = os.path.join(os.path.dirname(exe), "python.exe")
        if os.path.exists(sibling):
            return sibling
    return exe


def resolve_pythonw() -> str:
    """Windowless interpreter, used for the optional startup shortcut."""
    exe = sys.executable or "python"
    name = os.path.basename(exe).lower()
    if name.startswith("python") and not name.startswith("pythonw"):
        sibling = os.path.join(os.path.dirname(exe), "pythonw.exe")
        if os.path.exists(sibling):
            return sibling
    return exe


def guess_proxy_folder() -> str:
    here = Path(__file__).resolve().parent
    candidates = [
        here,
        here / "llm7-codex-proxy",
        Path.cwd(),
        Path.home() / "llm7-codex-proxy",
        Path.home() / "Downloads" / "llm7-codex-proxy",
        Path.home() / "Documents" / "llm7-codex-proxy",
    ]
    for folder in candidates:
        try:
            if (folder / SCRIPT_NAME).is_file():
                return str(folder)
        except Exception:
            continue
    return ""


def no_window_flags() -> int:
    if not IS_WINDOWS:
        return 0
    return getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000) | getattr(
        subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200
    )


# ------------------------------------------------------------------- widgets


def make_button(parent, text, command, kind="secondary", width=None):
    palette = {
        "primary": (C_BLUE, "#FFFFFF", "#1F6FBE"),
        "secondary": (C_SURFACE2, C_TEXT, "#E2E1DE"),
        "danger": (C_RED_SOFT, C_RED, "#F7D9D5"),
        "ghost": (C_CANVAS, C_BLUE, C_BLUE_SOFT),
    }
    bg, fg, active = palette[kind]
    weight = "bold" if kind == "primary" else "normal"
    button = tk.Button(
        parent,
        text=text,
        command=command,
        bg=bg,
        fg=fg,
        activebackground=active,
        activeforeground=fg,
        disabledforeground=C_TEXT2,
        relief="flat",
        bd=0,
        highlightthickness=0,
        padx=12,
        pady=6,
        cursor="hand2",
        font=(FONT, 9, weight),
    )
    if width:
        button.configure(width=width)
    return button


def make_entry(parent, textvariable, show=None, width=None):
    entry = tk.Entry(
        parent,
        textvariable=textvariable,
        show=show or "",
        bg=C_CANVAS,
        fg=C_TEXT,
        relief="flat",
        bd=0,
        highlightthickness=1,
        highlightbackground=C_BORDER,
        highlightcolor=C_BLUE,
        insertbackground=C_TEXT,
        font=(FONT, 9),
    )
    if width:
        entry.configure(width=width)
    return entry


def make_card(parent, step, title, subtitle=""):
    outer = tk.Frame(
        parent,
        bg=C_CANVAS,
        highlightbackground=C_BORDER,
        highlightthickness=1,
        bd=0,
    )
    head = tk.Frame(outer, bg=C_CANVAS)
    head.pack(fill="x", padx=14, pady=(8, 0))
    badge = tk.Label(
        head,
        text=str(step),
        bg=C_BLUE_SOFT,
        fg=C_BLUE,
        font=(FONT, 8, "bold"),
        padx=6,
        pady=0,
    )
    badge.pack(side="left", pady=(1, 0))
    tk.Label(head, text=title, bg=C_CANVAS, fg=C_TEXT, font=(FONT, 10, "bold")).pack(
        side="left", padx=(7, 0)
    )
    if subtitle:
        tk.Label(
            outer, text=subtitle, bg=C_CANVAS, fg=C_TEXT2, font=(FONT, 8), anchor="w"
        ).pack(fill="x", padx=14, pady=(2, 0))
    body = tk.Frame(outer, bg=C_CANVAS)
    body.pack(fill="x", padx=14, pady=(7, 9))
    return outer, body


# --------------------------------------------------------------------- app


class ControlPanel:
    def __init__(self, root):
        self.root = root
        self.proc = None
        self.log_queue: "queue.Queue[str]" = queue.Queue()
        self.settings = load_settings()
        self.busy = False

        self.key_var = tk.StringVar()
        self.show_key = tk.BooleanVar(value=False)
        self.folder_var = tk.StringVar()
        self.port_var = tk.StringVar(value=DEFAULT_PORT)
        self.codex_model_var = tk.StringVar(value=DEFAULT_CODEX_MODEL)
        self.upstream_model_var = tk.StringVar(value=DEFAULT_UPSTREAM_MODEL)
        self.debug_var = tk.BooleanVar(value=True)

        self._build_ui()
        self._restore()
        self.refresh_status()
        self.log("Ready. Work top to bottom - every step is a button.")
        self.root.after(150, self._tick)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    # ---------------------------------------------------------------- build

    def _build_ui(self):
        root = self.root
        root.configure(bg=C_SOFT)

        # The Activity log is pinned to the bottom of the window, and the four
        # cards live in a scrollable area above it. That way the Run the proxy
        # buttons are always reachable, whatever the screen size or Windows
        # display scaling.
        log_holder = tk.Frame(root, bg=C_SOFT)
        log_holder.pack(side="bottom", fill="x", padx=18, pady=(0, 12))

        shell = tk.Frame(root, bg=C_SOFT)
        shell.pack(side="top", fill="both", expand=True)
        self.canvas = tk.Canvas(shell, bg=C_SOFT, highlightthickness=0, bd=0)
        self.vbar = tk.Scrollbar(shell, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.vbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.vbar.pack(side="right", fill="y")

        page = tk.Frame(self.canvas, bg=C_SOFT)
        self.page_id = self.canvas.create_window((0, 0), window=page, anchor="nw")
        page.bind("<Configure>", self._on_page_resize)
        self.canvas.bind("<Configure>", self._on_canvas_resize)
        root.bind("<MouseWheel>", self._on_wheel)
        root.bind("<Button-4>", self._on_wheel)
        root.bind("<Button-5>", self._on_wheel)

        header = tk.Frame(page, bg=C_SOFT)
        header.pack(fill="x", padx=18, pady=(12, 8))
        tk.Label(
            header,
            text="LLM7 Codex Proxy",
            bg=C_SOFT,
            fg=C_TEXT,
            font=(FONT, 14, "bold"),
        ).pack(side="left")
        tk.Label(
            header,
            text="Control panel - no terminal needed",
            bg=C_SOFT,
            fg=C_TEXT2,
            font=(FONT, 9),
        ).pack(side="left", padx=(10, 0), pady=(3, 0))

        pills = tk.Frame(page, bg=C_SOFT)
        pills.pack(fill="x", padx=18, pady=(0, 10))
        self.pill_key = self._pill(pills, "Key")
        self.pill_config = self._pill(pills, "Config")
        self.pill_proxy = self._pill(pills, "Proxy")

        body = tk.Frame(page, bg=C_SOFT)
        body.pack(fill="both", expand=True, padx=18, pady=(0, 4))

        self._build_key_card(body)
        self._build_folder_card(body)
        self._build_config_card(body)
        self._build_run_card(body)
        self._build_log(log_holder)

    # ------------------------------------------------------------ scrolling

    def _on_page_resize(self, event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas_resize(self, event):
        self.canvas.itemconfigure(self.page_id, width=event.width)

    def _on_wheel(self, event):
        if getattr(event, "widget", None) is getattr(self, "log_text", None):
            return
        delta = getattr(event, "delta", 0)
        if delta:
            step = -1 if delta > 0 else 1
        else:
            step = -1 if getattr(event, "num", 5) == 4 else 1
        self.canvas.yview_scroll(step, "units")

    def _pill(self, parent, label):
        holder = tk.Frame(parent, bg=C_SURFACE2, padx=9, pady=3)
        holder.pack(side="left", padx=(0, 7))
        tk.Label(
            holder, text=label.upper(), bg=C_SURFACE2, fg=C_TEXT2, font=(FONT, 7, "bold")
        ).pack(side="left")
        value = tk.Label(
            holder, text="-", bg=C_SURFACE2, fg=C_TEXT, font=(FONT, 8, "bold")
        )
        value.pack(side="left", padx=(6, 0))
        return {"holder": holder, "value": value}

    def _set_pill(self, pill, text, tone="neutral"):
        tones = {
            "good": (C_GREEN_SOFT, C_GREEN),
            "warn": (C_ORANGE_SOFT, C_ORANGE),
            "bad": (C_RED_SOFT, C_RED),
            "neutral": (C_SURFACE2, C_TEXT2),
        }
        bg, fg = tones[tone]
        pill["holder"].configure(bg=bg)
        for child in pill["holder"].winfo_children():
            child.configure(bg=bg)
        pill["value"].configure(fg=fg, text=text)

    def _build_key_card(self, parent):
        card, body = make_card(
            parent,
            1,
            "LLM7 API key",
            "Saved as the Windows user variable LLM7_API_KEY. Leave blank to run in free mode.",
        )
        card.pack(fill="x", pady=(0, 9))

        row = tk.Frame(body, bg=C_CANVAS)
        row.pack(fill="x")
        self.key_entry = make_entry(row, self.key_var, show="*")
        self.key_entry.pack(side="left", fill="x", expand=True, ipady=5, padx=(0, 10))
        make_button(row, "Save key", self.on_save_key, kind="primary").pack(side="left")

        tools = tk.Frame(body, bg=C_CANVAS)
        tools.pack(fill="x", pady=(6, 0))
        tk.Checkbutton(
            tools,
            text="Show key",
            variable=self.show_key,
            command=self.on_toggle_key,
            bg=C_CANVAS,
            fg=C_TEXT2,
            activebackground=C_CANVAS,
            activeforeground=C_TEXT,
            selectcolor=C_CANVAS,
            font=(FONT, 8),
            bd=0,
            highlightthickness=0,
            cursor="hand2",
        ).pack(side="left")
        make_button(tools, "Get a free key", self.on_open_dash, kind="ghost").pack(
            side="left", padx=(6, 0)
        )
        make_button(tools, "Free mode", self.on_free_mode, kind="ghost").pack(
            side="left"
        )
        make_button(tools, "Remove saved key", self.on_clear_key, kind="ghost").pack(
            side="left"
        )
        self.key_hint = tk.Label(
            body, text="", bg=C_CANVAS, fg=C_TEXT2, font=(FONT, 8), anchor="w"
        )
        self.key_hint.pack(fill="x", pady=(6, 0))

    def _build_folder_card(self, parent):
        card, body = make_card(
            parent,
            2,
            "Proxy folder",
            "The folder that contains {0}.".format(SCRIPT_NAME),
        )
        card.pack(fill="x", pady=(0, 9))

        row = tk.Frame(body, bg=C_CANVAS)
        row.pack(fill="x")
        self.folder_entry = make_entry(row, self.folder_var)
        self.folder_entry.pack(side="left", fill="x", expand=True, ipady=5, padx=(0, 10))
        make_button(row, "Browse", self.on_browse).pack(side="left")

        actions = tk.Frame(body, bg=C_CANVAS)
        actions.pack(fill="x", pady=(6, 0))
        self.install_btn = make_button(actions, "Install requirements", self.on_install)
        self.install_btn.pack(side="left")
        self.uninstall_btn = make_button(
            actions, "Uninstall requirements", self.on_uninstall, kind="danger"
        )
        self.uninstall_btn.pack(side="left", padx=(8, 0))

        self.folder_hint = tk.Label(
            body, text="", bg=C_CANVAS, fg=C_TEXT2, font=(FONT, 8), anchor="w"
        )
        self.folder_hint.pack(fill="x", pady=(6, 0))

    def _build_config_card(self, parent):
        card, body = make_card(
            parent,
            3,
            "Codex config",
            "Writes the provider block into {0} and keeps your other settings.".format(
                codex_config_path()
            ),
        )
        card.pack(fill="x", pady=(0, 9))

        grid = tk.Frame(body, bg=C_CANVAS)
        grid.pack(fill="x")
        fields = (
            ("Local port", self.port_var, 8),
            ("Codex model", self.codex_model_var, 14),
            ("Upstream LLM7 model", self.upstream_model_var, 12),
        )
        for column, (label, var, width) in enumerate(fields):
            cell = tk.Frame(grid, bg=C_CANVAS)
            cell.grid(row=0, column=column, sticky="w", padx=(0, 18))
            tk.Label(
                cell, text=label, bg=C_CANVAS, fg=C_TEXT2, font=(FONT, 8), anchor="w"
            ).pack(fill="x")
            make_entry(cell, var, width=width).pack(anchor="w", ipady=4, pady=(3, 0))

        row = tk.Frame(body, bg=C_CANVAS)
        row.pack(fill="x", pady=(10, 0))
        make_button(row, "Write Codex config", self.on_write_config, kind="primary").pack(
            side="left"
        )
        self.restore_btn = make_button(
            row, "Restore original config", self.on_restore_config, kind="danger"
        )
        self.restore_btn.pack(side="left", padx=(8, 0))
        make_button(row, "Open config folder", self.on_open_config_folder).pack(
            side="left", padx=(8, 0)
        )
        self.config_hint = tk.Label(
            body, text="", bg=C_CANVAS, fg=C_TEXT2, font=(FONT, 8), anchor="w"
        )
        self.config_hint.pack(fill="x", pady=(6, 0))

    def _build_run_card(self, parent):
        card, body = make_card(
            parent, 4, "Run the proxy", "Keep this window open while you use Codex."
        )
        card.pack(fill="x", pady=(0, 9))

        row = tk.Frame(body, bg=C_CANVAS)
        row.pack(fill="x")
        self.start_btn = make_button(row, "Start proxy", self.on_start, kind="primary")
        self.start_btn.pack(side="left")
        self.stop_btn = make_button(row, "Stop", self.on_stop, kind="danger")
        self.stop_btn.pack(side="left", padx=(8, 0))
        make_button(row, "Check health", self.on_health).pack(side="left", padx=(8, 0))
        self.startup_btn = make_button(row, "Start with Windows", self.on_startup_toggle)
        self.startup_btn.pack(side="left", padx=(8, 0))

        tk.Checkbutton(
            body,
            text="Write debug dumps (debug-dumps folder - keep private)",
            variable=self.debug_var,
            bg=C_CANVAS,
            fg=C_TEXT2,
            activebackground=C_CANVAS,
            activeforeground=C_TEXT,
            selectcolor=C_CANVAS,
            font=(FONT, 8),
            bd=0,
            highlightthickness=0,
            cursor="hand2",
        ).pack(anchor="w", pady=(8, 0))

    def _build_log(self, parent):
        wrap = tk.Frame(
            parent, bg=C_CANVAS, highlightbackground=C_BORDER, highlightthickness=1
        )
        wrap.pack(fill="x")
        bar = tk.Frame(wrap, bg=C_CANVAS)
        bar.pack(fill="x", padx=12, pady=(7, 0))
        tk.Label(bar, text="Activity", bg=C_CANVAS, fg=C_TEXT, font=(FONT, 9, "bold")).pack(
            side="left"
        )
        make_button(bar, "Clear", self.on_clear_log, kind="ghost").pack(side="right")

        self.log_text = ScrolledText(
            wrap,
            height=5,
            bg=C_SOFT,
            fg=C_TEXT,
            relief="flat",
            bd=0,
            font=(MONO, 8),
            wrap="word",
            insertbackground=C_TEXT,
        )
        self.log_text.pack(fill="x", padx=12, pady=(6, 9))
        self.log_text.configure(state="disabled")

    # -------------------------------------------------------------- helpers

    def log(self, message: str):
        stamp = datetime.now().strftime("%H:%M:%S")
        self._write_log("[{0}] {1}".format(stamp, message))

    def _write_log(self, line: str):
        self.log_text.configure(state="normal")
        self.log_text.insert("end", line.rstrip("\n") + "\n")
        if int(self.log_text.index("end-1c").split(".")[0]) > 4000:
            self.log_text.delete("1.0", "2000.0")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def on_clear_log(self):
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")

    def _restore(self):
        saved = read_saved_key()
        if saved:
            self.key_var.set(saved)
        folder = self.settings.get("folder") or guess_proxy_folder()
        self.folder_var.set(folder)
        self.port_var.set(self.settings.get("port") or DEFAULT_PORT)
        self.codex_model_var.set(
            self.settings.get("codex_model") or DEFAULT_CODEX_MODEL
        )
        self.upstream_model_var.set(
            self.settings.get("upstream_model") or DEFAULT_UPSTREAM_MODEL
        )
        self.debug_var.set(bool(self.settings.get("debug", True)))

    def _persist(self):
        save_settings(
            {
                "folder": self.folder_var.get().strip(),
                "port": self.port_var.get().strip(),
                "codex_model": self.codex_model_var.get().strip(),
                "upstream_model": self.upstream_model_var.get().strip(),
                "debug": bool(self.debug_var.get()),
            }
        )

    def script_path(self):
        folder = self.folder_var.get().strip()
        if not folder:
            return None
        candidate = Path(folder) / SCRIPT_NAME
        return candidate if candidate.is_file() else None

    def refresh_status(self):
        saved = read_saved_key()
        if not saved:
            self._set_pill(self.pill_key, "not saved", "warn")
            self.key_hint.configure(
                text="No key saved yet. Free mode works without one, with lower limits."
            )
        elif saved == FREE_KEY:
            self._set_pill(self.pill_key, "free mode", "neutral")
            self.key_hint.configure(
                text="Saved as \"unused\" (free mode). Save a real key for better limits."
            )
        else:
            self._set_pill(self.pill_key, "saved", "good")
            self.key_hint.configure(
                text="Saved in Windows user variables: {0} = {1}".format(
                    ENV_KEY, mask_key(saved)
                )
            )

        script = self.script_path()
        if script:
            self.folder_hint.configure(text="Found {0}".format(script))
        else:
            self.folder_hint.configure(
                text="Pick the folder that contains {0}.".format(SCRIPT_NAME)
            )

        config = codex_config_path()
        if original_backup_path().is_file():
            saved_note = "  -  original kept as {0}".format(original_backup_path().name)
        elif no_original_marker_path().is_file():
            saved_note = "  -  no config existed before; Restore removes this file"
        else:
            saved_note = "  -  no backup taken yet"
        if config.is_file():
            try:
                text = config.read_text(encoding="utf-8", errors="replace")
            except Exception:
                text = ""
            if "[model_providers.{0}]".format(PROVIDER_KEY) in text.replace(" ", ""):
                self._set_pill(self.pill_config, "ready", "good")
                self.config_hint.configure(
                    text="Provider block present in {0}{1}".format(config, saved_note)
                )
            else:
                self._set_pill(self.pill_config, "not wired", "warn")
                self.config_hint.configure(
                    text="config.toml exists but has no {0} provider yet.".format(
                        PROVIDER_KEY
                    )
                )
        else:
            self._set_pill(self.pill_config, "missing", "warn")
            self.config_hint.configure(text="No config.toml yet - it will be created.")

        running = self.proc is not None and self.proc.poll() is None
        if running:
            self._set_pill(
                self.pill_proxy, "running :{0}".format(self.port_var.get().strip()), "good"
            )
        else:
            self._set_pill(self.pill_proxy, "stopped", "neutral")
        self.start_btn.configure(state="disabled" if running or self.busy else "normal")
        self.stop_btn.configure(state="normal" if running else "disabled")
        busy_state = "disabled" if self.busy else "normal"
        self.install_btn.configure(state=busy_state)
        self.uninstall_btn.configure(state=busy_state)
        self.restore_btn.configure(
            state="normal" if can_restore_original() and not self.busy else "disabled"
        )

        on_startup = (startup_dir() / STARTUP_FILE).is_file()
        self.startup_btn.configure(
            text="Remove from startup" if on_startup else "Start with Windows"
        )

    # --------------------------------------------------------------- step 1

    def on_toggle_key(self):
        self.key_entry.configure(show="" if self.show_key.get() else "*")

    def on_open_dash(self):
        webbrowser.open(DASH_URL)
        self.log("Opened {0} in your browser.".format(DASH_URL))

    def on_free_mode(self):
        self.key_var.set(FREE_KEY)
        self.on_save_key()

    def on_save_key(self):
        value = self.key_var.get().strip() or FREE_KEY
        try:
            write_saved_key(value)
        except Exception as exc:
            messagebox.showerror(APP_NAME, "Could not save the key:\n{0}".format(exc))
            return
        if not IS_WINDOWS:
            self.log(
                "Saved for this session only. Permanent saving is Windows-only."
            )
        else:
            self.log(
                "Saved {0} in your Windows user variables ({1}).".format(
                    ENV_KEY, mask_key(value)
                )
            )
            self.log("Restart the Codex app once so it picks up the new variable.")
        self.refresh_status()

    def on_clear_key(self):
        if not messagebox.askyesno(APP_NAME, "Remove the saved {0} variable?".format(ENV_KEY)):
            return
        try:
            delete_saved_key()
        except Exception as exc:
            messagebox.showerror(APP_NAME, "Could not remove the key:\n{0}".format(exc))
            return
        self.key_var.set("")
        self.log("Removed the saved {0} variable.".format(ENV_KEY))
        self.refresh_status()

    # --------------------------------------------------------------- step 2

    def on_browse(self):
        start = self.folder_var.get().strip() or str(Path.home())
        chosen = filedialog.askdirectory(
            title="Select the folder containing {0}".format(SCRIPT_NAME),
            initialdir=start,
        )
        if not chosen:
            return
        self.folder_var.set(chosen)
        self._persist()
        if not self.script_path():
            messagebox.showwarning(
                APP_NAME,
                "{0} was not found in that folder.".format(SCRIPT_NAME),
            )
        self.refresh_status()

    def on_install(self):
        folder = self.folder_var.get().strip()
        if not folder or not Path(folder).is_dir():
            messagebox.showwarning(APP_NAME, "Pick the proxy folder first.")
            return
        requirements = Path(folder) / "requirements.txt"
        if not requirements.is_file():
            messagebox.showwarning(APP_NAME, "No requirements.txt in that folder.")
            return
        self.busy = True
        self.refresh_status()
        self.log("Installing requirements. This can take a minute.")
        command = [
            resolve_python(),
            "-m",
            "pip",
            "install",
            "-r",
            str(requirements),
        ]
        threading.Thread(
            target=self._run_and_stream, args=(command, folder), daemon=True
        ).start()

    def on_uninstall(self):
        folder = self.folder_var.get().strip()
        if not folder or not Path(folder).is_dir():
            messagebox.showwarning(APP_NAME, "Pick the proxy folder first.")
            return
        requirements = Path(folder) / "requirements.txt"
        if not requirements.is_file():
            messagebox.showwarning(APP_NAME, "No requirements.txt in that folder.")
            return
        if self.proc is not None and self.proc.poll() is None:
            messagebox.showwarning(
                APP_NAME, "Stop the proxy before removing its packages."
            )
            return
        if not messagebox.askyesno(
            APP_NAME,
            "Remove every package listed in requirements.txt from this Python?\n\n"
            "Other projects on this PC that share those packages may stop working.",
        ):
            return
        self.busy = True
        self.refresh_status()
        self.log("Uninstalling requirements.")
        command = [
            resolve_python(),
            "-m",
            "pip",
            "uninstall",
            "-y",
            "-r",
            str(requirements),
        ]
        threading.Thread(
            target=self._run_and_stream, args=(command, folder), daemon=True
        ).start()

    def _run_and_stream(self, command, cwd):
        try:
            proc = subprocess.Popen(
                command,
                cwd=cwd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                encoding="utf-8",
                errors="replace",
                creationflags=no_window_flags(),
            )
            for line in proc.stdout:
                self.log_queue.put(line.rstrip())
            proc.wait()
            self.log_queue.put(
                "Finished with exit code {0}.".format(proc.returncode)
            )
        except Exception as exc:
            self.log_queue.put("Failed: {0}".format(exc))
        finally:
            self.log_queue.put("__DONE__")

    # --------------------------------------------------------------- step 3

    def on_write_config(self):
        port = self.port_var.get().strip()
        if not valid_port(port):
            messagebox.showwarning(APP_NAME, "Port must be a number between 1 and 65535.")
            return
        model = self.codex_model_var.get().strip() or DEFAULT_CODEX_MODEL
        path = codex_config_path()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            state = ensure_original_backup()
            if state == "created":
                self.log(
                    "Saved your untouched config as {0} - Restore original config "
                    "brings it back.".format(original_backup_path().name)
                )
            elif state == "absent":
                self.log(
                    "There was no config.toml before, so Restore original config "
                    "will remove the new one."
                )
            else:
                self.log(
                    "Original config already preserved as {0} - keeping that first "
                    "copy.".format(original_backup_path().name)
                )
            existing = ""
            if path.is_file():
                existing = path.read_text(encoding="utf-8", errors="replace")
                backup = path.with_suffix(".toml.bak-{0}".format(timestamp()))
                shutil.copy2(path, backup)
                self.log("Backed up the current config to {0}".format(backup.name))
            path.write_text(patch_config_text(existing, port, model), encoding="utf-8")
        except Exception as exc:
            messagebox.showerror(APP_NAME, "Could not write config.toml:\n{0}".format(exc))
            return
        self._persist()
        self.log("Wrote {0}".format(path))
        self.log("Codex will use model {0} through the local proxy.".format(model))
        self.refresh_status()

    def on_restore_config(self):
        if not can_restore_original():
            messagebox.showinfo(
                APP_NAME,
                "No original config has been saved yet. Write the Codex config "
                "once and a pristine copy is kept automatically.",
            )
            return
        original = original_backup_path()
        if original.is_file():
            question = (
                "Put your original config.toml back?\n\n"
                "The current file is copied to a .before-restore file first, then "
                "replaced with {0}.".format(original.name)
            )
        else:
            question = (
                "You had no config.toml before this app wrote one.\n\n"
                "Restoring will delete the config.toml it created."
            )
        if not messagebox.askyesno(APP_NAME, question):
            return
        try:
            action, safety = restore_original()
        except Exception as exc:
            messagebox.showerror(APP_NAME, "Could not restore:\n{0}".format(exc))
            return
        if safety is not None:
            self.log("Kept a copy of the replaced file as {0}".format(safety.name))
        if action == "restored":
            self.log("Restored your original {0}".format(codex_config_path()))
        elif action == "removed":
            self.log(
                "Deleted the config.toml this app created - back to your original state."
            )
        else:
            self.log("Nothing to restore.")
        self.log("Restart the Codex app so it reloads the config.")
        self.refresh_status()

    def on_open_config_folder(self):
        folder = codex_config_path().parent
        try:
            folder.mkdir(parents=True, exist_ok=True)
            if IS_WINDOWS and hasattr(os, "startfile"):
                os.startfile(str(folder))
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(folder)])
            else:
                subprocess.Popen(["xdg-open", str(folder)])
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    # --------------------------------------------------------------- step 4

    def on_start(self):
        script = self.script_path()
        if not script:
            messagebox.showwarning(
                APP_NAME, "Pick the folder that contains {0} first.".format(SCRIPT_NAME)
            )
            return
        port = self.port_var.get().strip()
        if not valid_port(port):
            messagebox.showwarning(APP_NAME, "Port must be a number between 1 and 65535.")
            return
        if port_busy(port):
            if not messagebox.askyesno(
                APP_NAME,
                "Something is already listening on port {0}.\n\n"
                "It may be a proxy you started earlier. Start another one anyway?".format(
                    port
                ),
            ):
                return

        env = os.environ.copy()
        env[ENV_KEY] = self.key_var.get().strip() or read_saved_key() or FREE_KEY
        env["PROXY_HOST"] = "127.0.0.1"
        env["PROXY_PORT"] = port
        env["LLM7_MODEL"] = (
            self.upstream_model_var.get().strip() or DEFAULT_UPSTREAM_MODEL
        )
        env["CODEX_PROXY_DEBUG"] = "1" if self.debug_var.get() else "0"
        env["PYTHONUNBUFFERED"] = "1"

        try:
            self.proc = subprocess.Popen(
                [resolve_python(), str(script)],
                cwd=str(script.parent),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                encoding="utf-8",
                errors="replace",
                env=env,
                creationflags=no_window_flags(),
            )
        except Exception as exc:
            self.proc = None
            messagebox.showerror(APP_NAME, "Could not start the proxy:\n{0}".format(exc))
            return

        threading.Thread(target=self._pump_proxy, daemon=True).start()
        self._persist()
        self.log(
            "Started the proxy on http://127.0.0.1:{0} using key {1}.".format(
                port, mask_key(env[ENV_KEY])
            )
        )
        self.log("Now open the Codex app. Leave this window open.")
        self.refresh_status()

    def _pump_proxy(self):
        proc = self.proc
        if proc is None or proc.stdout is None:
            return
        for line in proc.stdout:
            self.log_queue.put(line.rstrip())

    def on_stop(self):
        proc = self.proc
        if proc is None or proc.poll() is not None:
            self.proc = None
            self.refresh_status()
            return
        self.log("Stopping the proxy.")
        try:
            if IS_WINDOWS:
                subprocess.run(
                    ["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                    capture_output=True,
                    creationflags=no_window_flags(),
                )
            else:
                proc.terminate()
            try:
                proc.wait(timeout=6)
            except Exception:
                proc.kill()
        except Exception as exc:
            self.log("Could not stop cleanly: {0}".format(exc))
        self.refresh_status()

    def on_health(self):
        port = self.port_var.get().strip()
        if not valid_port(port):
            messagebox.showwarning(APP_NAME, "Port must be a number between 1 and 65535.")
            return
        url = "http://127.0.0.1:{0}/health".format(port)
        self.log("Checking {0}".format(url))
        threading.Thread(target=self._health_worker, args=(url,), daemon=True).start()

    def _health_worker(self, url):
        try:
            with urllib.request.urlopen(url, timeout=5) as response:
                payload = response.read(600).decode("utf-8", "replace").strip()
                self.log_queue.put(
                    "Health {0}: {1}".format(getattr(response, "status", 200), payload)
                )
        except urllib.error.URLError as exc:
            self.log_queue.put(
                "No answer from {0} ({1}). Start the proxy first.".format(url, exc.reason)
            )
        except Exception as exc:
            self.log_queue.put("Health check failed: {0}".format(exc))

    def on_startup_toggle(self):
        target = startup_dir() / STARTUP_FILE
        if target.is_file():
            try:
                target.unlink()
            except Exception as exc:
                messagebox.showerror(APP_NAME, str(exc))
                return
            self.log("Removed the proxy from Windows startup.")
            self.refresh_status()
            return

        script = self.script_path()
        if not script:
            messagebox.showwarning(
                APP_NAME, "Pick the folder that contains {0} first.".format(SCRIPT_NAME)
            )
            return
        if not IS_WINDOWS:
            messagebox.showinfo(APP_NAME, "This option is Windows-only.")
            return
        content = (
            "@echo off\r\n"
            'cd /d "{folder}"\r\n'
            'start "" /min "{python}" "{script}"\r\n'
        ).format(
            folder=str(script.parent), python=resolve_pythonw(), script=str(script)
        )
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return
        self.log("The proxy will now start automatically when you sign in.")
        self.refresh_status()

    # ----------------------------------------------------------------- loop

    def _tick(self):
        try:
            while True:
                line = self.log_queue.get_nowait()
                if line == "__DONE__":
                    self.busy = False
                    self.refresh_status()
                else:
                    self._write_log(line)
        except queue.Empty:
            pass

        if self.proc is not None and self.proc.poll() is not None:
            code = self.proc.returncode
            self.proc = None
            self.log("Proxy stopped (exit code {0}).".format(code))
            self.refresh_status()

        self.root.after(150, self._tick)

    def on_close(self):
        if self.proc is not None and self.proc.poll() is None:
            if not messagebox.askyesno(
                APP_NAME, "The proxy is running. Stop it and close?"
            ):
                return
            self.on_stop()
        self._persist()
        self.root.destroy()


def main() -> int:
    if not HAVE_TK:
        print(
            "This app needs tkinter, which ships with the python.org Windows installer."
        )
        return 1
    if IS_WINDOWS:
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            try:
                ctypes.windll.user32.SetProcessDPIAware()
            except Exception:
                pass
    root = tk.Tk()
    root.title("{0} - Control Panel".format(APP_NAME))

    # Size the window from the real screen and its display scaling, then centre
    # it, so every card fits on screen instead of running off the bottom.
    scale = 1.0
    try:
        scale = max(1.0, min(2.0, root.winfo_fpixels("1i") / 96.0))
    except Exception:
        pass
    screen_w = root.winfo_screenwidth()
    screen_h = root.winfo_screenheight()
    width = max(640, min(int(860 * scale), screen_w - 80))
    height = max(520, min(int(880 * scale), screen_h - 110))
    root.geometry(
        "{0}x{1}+{2}+{3}".format(
            width,
            height,
            max(0, (screen_w - width) // 2),
            max(0, (screen_h - height) // 4),
        )
    )
    root.minsize(min(700, width), min(460, height))
    ControlPanel(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
