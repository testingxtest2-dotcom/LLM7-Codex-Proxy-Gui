@echo off
setlocal
cd /d "%~dp0"
set "GUI=%~dp0llm7_proxy_gui.py"

if not exist "%GUI%" (
  echo Could not find llm7_proxy_gui.py next to this file.
  pause
  exit /b 1
)

rem Prefer the windowless interpreter so no black console window appears.
where pythonw.exe >nul 2>&1
if not errorlevel 1 (
  start "" pythonw.exe "%GUI%"
  exit /b 0
)

where pyw.exe >nul 2>&1
if not errorlevel 1 (
  start "" pyw.exe -3 "%GUI%"
  exit /b 0
)

where python.exe >nul 2>&1
if not errorlevel 1 (
  start "" python.exe "%GUI%"
  exit /b 0
)

where py.exe >nul 2>&1
if not errorlevel 1 (
  start "" py.exe -3 "%GUI%"
  exit /b 0
)

echo Python was not found on this PC.
echo Install Python 3.10 or newer from https://www.python.org/downloads/windows/
echo and tick "Add python.exe to PATH" during setup.
pause
exit /b 1
